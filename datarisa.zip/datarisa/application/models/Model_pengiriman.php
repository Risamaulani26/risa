<?php
class Model_pengiriman extends CI_Model
{

    public function getAllPengiriman($keyword = null)
    {
        if( $keyword ) {
            $this->db->like('nama_barang', $keyword);
            $this->db->or_like('tanggal_masuk', $keyword);
            $this->db->or_like('alamat', $keyword);
            $this->db->or_like('keterangan', $keyword);
            $this->db->or_like('nama_pengantar', $keyword);
        }
        
        return $query = $this->db->get('pengiriman')->result_array();
    }

    public function TambahPengiriman()
    {
        $upload_image = $_FILES['image']['name'];
            if($upload_image) {
            $config['allowed_types'] = 'gif|jpg|png|jpeg|jfif';
            $config['max_size'] = '2048';
            $config['upload_path'] = './assets/foto/';

            $this->load->library('upload', $config);

            if($this->upload->do_upload('image')) {
                $foto = $this->upload->data('file_name');
                $data = [
                    "foto" => $foto,
                    "nama_barang" => $this->input->post('nama_barang', true),
                    "tanggal_masuk" => $this->input->post('tanggal_masuk', true),
                    "alamat" => $this->input->post('alamat', true),
                    "keterangan" => $this->input->post('keterangan', true),
                    "nama_pengantar" => $this->input->post('nama_pengantar', true),
                ];

                $this->db->insert('pengiriman', $data);

                $this->session->set_flashdata('flash', 'Ditambahkan');

            }else {
                $this->session->set_flashdata('error', $this->upload->display_errors());
            }
        }
    }


    public function Ubahpengiriman()
    {
        $upload_image = $_FILES['image']['name'];
            if($upload_image) {
            $config['allowed_types'] = 'gif|jpg|png|jpeg|jfif';
            $config['max_size'] = '2048';
            $config['upload_path'] = './assets/foto/';

            $this->load->library('upload', $config);

            if($this->upload->do_upload('image')) {
                $foto = $this->upload->data('file_name');
                $this->db->set('foto', $foto);
            }else {
                $this->session->set_flashdata('error', $this->upload->display_error());
            }
        }
        
        $id = $this->input->post('id', true);
        $nama_barang = $this->input->post('nama_barang', true);
        $tanggal_masuk = $this->input->post('tanggal_masuk', true);
        $alamat = $this->input->post('alamat', true);
        $keterangan = $this->input->post('keterangan', true);
        $nama_pengantar = $this->input->post('nama_pengantar', true);

        $this->db->set('id', $id);
        $this->db->set('nama_barang', $nama_barang);
        $this->db->set('tanggal_masuk', $tanggal_masuk);
        $this->db->set('alamat', $alamat);
        $this->db->set('keterangan', $keterangan);
        $this->db->set('nama_pengantar', $nama_pengantar);

        $this->db->where('id', $id);
        $this->db->update('pengiriman');
    }

    public function hapusPengiriman($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('pengiriman');
    }

    public function getPengirimanById($id)
    {
        return $query = $this->db->get_where('pengiriman', ['id' => $id])->row_array();
    }

    public function Caripengiriman()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('id', $keyword);
        $this->db->or-like('nama_barang', $keyword);
        $this->db->or-like('tanggal_masuk', $keyword);
        $this->db->or-like('alamat', $keyword);
        $this->db->or-like('keterangan', $keyword);
        $this->db->or-like('nama_pengantar', $keyword);
        return $this->db->get('pengiriman')->result_array();
    }
}

