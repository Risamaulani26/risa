<?php
class Model_kurir extends CI_model
{
    public function getAllKurir()
    {
        return $query = $this->db->get('kurir')->result_array();
    }

    public function Tambahkurir()
    {
        $data = [
            "kurir" => $this->input->post('kurir', true)
        ];

        $this->db->insert('kurir', $data);
    }

    public function Ubahkurir()
    {
        $data = [
            "kurir" => $this->input->post('kurir', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('kurir', $data);
    }

    public function hapusKurir($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('kurir');
    }

    public function getKurirById($id)
    {
        return $query = $this->db->get_where('kurir', ['id' => $id])->row_array();
    }

    public function Carikurir()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('nama', $keyword);
        return $this->db->get('kurir')->result_array();
    }
}

?>