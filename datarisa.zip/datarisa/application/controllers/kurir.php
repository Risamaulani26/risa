<?php
defined('BASEPATH') OR exit('No direct script acces allowed');

class kurir extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Model_kurir');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] ='kurir';

        $data['kurir'] = $this->Model_kurir->getAllKurir();
        if( $this->input->post('keyword') ) {
            $data['kurir'] = $this->Model_kurir->Carikurir();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('kurir/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('kurir', 'kurir', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah kurir';

            $this->load->view('templates/header.php', $data);
            $this->load->view('kurir/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_kurir->tambahkurir();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('kurir');
        }
   
    }
    
    public function ubah($id)
    {
        $this->form_validation->set_rules('kurir', 'kurir', 'trim|required');
        $data['kurir'] = $this->Model_kurir->getkurirById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Kurir';

            $this->load->view('templates/header.php', $data);
            $this->load->view('kurir/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_kurir->Ubahkurir();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('kurir');
        }

    }
  
    public function hapus($id)
    {
        $this->Model_kurir->hapusKurir($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('kurir');
    }
}