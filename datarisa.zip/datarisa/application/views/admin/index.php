<div class="container">
    <h1>Selamat datang admin</h1>
</div>
<style>
    body {
        background-image:url("https://media.istockphoto.com/id/1266868926/id/vektor/interior-kantor-pos-dengan-orang-orang-mengirim-dan-menerima-surat-dan-kurir-pengiriman-paket.jpg?s=170667a&w=0&k=20&c=gXn8QKidxFwla0yj5WEQiSwUH76f4y9ZW7j2f-apGpk=")
    }
</style>
