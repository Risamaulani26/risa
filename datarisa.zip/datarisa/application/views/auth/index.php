        <div class="card mt-5" style="width: 30rem; margin: auto;">
          <div class="cardy-body">
            <h1 class="card-header">login</h1>
              <?php if( $this->session->flashdata('message') ) : ?>
                  <div class="alert alert-warning alert-dismissible fade show mt-2 mb-2" role="alert">
                      <strong><?= $this->session->flashdata('message'); ?></strong>
                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
              <?php endif; ?>
           <form method="post" action="<?= base_url('auth/index');?>">
             <div class="mb-3">
                <label for="username" class="from-label">Username</label>
                <input type="text" class="from-label" id="username" name="username">
                <?= form_error('password', '<small class="text-danger pl-3">', '</small>');?>
            </div>
            <div class="mb-3">
                <label for="password" class="from-label">Password</label>
                <input for="password" class="from-control" id="password" name="password">
                <?= form_error('password', '<small class="text-danger pl-3">', '</small>');?>
            </div>
            <input type="submit" value="submit" class="btn btn-primary"></input>
           </from>
           </div>
         </div>
            <style>
              body
              {
                background-image:url("https://media.istockphoto.com/id/1317478729/id/vektor/set-vektor-ikon-linear-terkait-proses-pengiriman-ekspres-rumah-pengiriman-nirsentut-dan.jpg?s=612x612&w=0&k=20&c=bh3jqZDoe8s5XibhVq8J5iH-vgZSI_UTn8m48AMa6LM=");
              }
            </style>