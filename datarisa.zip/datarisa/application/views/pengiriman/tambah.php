<div id="bg" class="container">
    <?= form_open_multipart('pengiriman/tambah');?>
        <legend>Tambah Data Pengiriman</legend>
        <div class="mb-3">
             <label for="formFile" class="form-label">Foto</label>
             <input class="form-control" type="file" id="formFile" name="image" style="width : 500px;" required>
             <div class="form-text text-danger"><?= form_error('image'); ?></div>
    </div>
    <div class="mb-3">
         <label for="nama_barang" class="form-label">nama_barang</label>
         <input type="text" class="form-control" id="nama_barang" name="nama_barang" style="width : 500px;">
         <div class="form-text text-danger"><?= form_error('nama_barang'); ?></div>
    </div>
    <div class="mb-3">
         <label for="tanggal_masuk" class="form-label">tanggal_masuk</label>
         <input type="date" class="form-control" id="tanggal_masuk" name="tanggal_masuk" style="width : 500px;">
         <div class="form-text text-danger"><?= form_error('tanggal_masuk'); ?></div>
    </div>
    <div class="mb-3">
         <label for="alamat" class="form-label">alamat</label>
         <input type="text" class="form-control" id="alamat" name="alamat" style="width : 500px;">
         <div class="form-text text-danger"><?= form_error('alamat'); ?></div>
    </div>
    <div class="mb-3">
         <label for="keterangan" class="form-label">keterangan</label>
         <input type="text" class="form-control" id="keterangan" name="keterangan" style="width : 500px;">
         <div class="form-text text-danger"><?= form_error('keterangan'); ?></div>
    </div>
    <div class="mb-3">
         <label for="nama_pengantar" class="form-label">nama_pengantar</label>
         <input type="text" class="form-control" id="nama_pengantar" name="nama_pengantar" style="width : 500px;">
         <div class="form-text text-danger"><?= form_error('nama_pengantar'); ?></div>
    </div>
    <input type="submit" value="submit" class="btn btn-primary"></input>
  </form>
</div>
<style>
    body {
        background: #FFE4C4;
    }
</style>