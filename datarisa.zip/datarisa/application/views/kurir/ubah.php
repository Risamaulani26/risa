<div class="container">
    <form action="" method="post">
        <legend>Ubah Data Nama Kurir</legend>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $kurir['id']; ?>">
            <label for="kurir" class="form-label">Nama Kurir</label>
            <input type="text" class="form-control" id="kurir" name="kurir" value="<?= $kurir['kurir']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('kurir'); ?></div>
        </div>
        <input type="submit" name="ubah" value="ubah" class="btn btn-primary"></input>
    </form>
</div>