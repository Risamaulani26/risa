<div class="container">
    <form action="" method="post">
        <legend>Tambah Data Nama Kurir</legend>
        <div class="mb-3">
            <label for="kurir" class="form-label">Nama Kurir</label>
            <input tyfr="text" class="fprm-control" id="kurir" name="kurir" style="width : 300px">
            <div class="form-text text-danger"><?= form_error('kurir'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
     </form>
</div>
<style>
    body {
        background: #FFE4C4;
    }
</style>